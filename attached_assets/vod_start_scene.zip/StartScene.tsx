
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function StartScene() {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setStep((s) => s + 1), step === 0 ? 6000 : 1000);
    return () => clearTimeout(timer);
  }, [step]);

  return (
    <div className="relative w-screen h-screen bg-[#050d1a] overflow-hidden flex items-center justify-center">
      {/* Гексагональный фон */}
      <div className="absolute inset-0 bg-[radial-gradient(circle,_#0a192f,_#050d1a)] animate-background-wave" />

      {/* Пульсация на старте */}
      <AnimatePresence>
        {step === 0 && (
          <motion.div
            className="absolute w-full h-full bg-transparent border border-blue-500/10"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0.2, 0.5, 0.2], scale: [1, 1.05, 1] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 5, repeat: Infinity }}
          />
        )}
      </AnimatePresence>

      {/* Капля и анимации */}
      <AnimatePresence>
        {step >= 1 && (
          <motion.img
            src="/logo-drop.png"
            alt="VODeco Logo"
            initial={{ y: "-200px", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2 }}
            className="w-32 h-32"
          />
        )}
      </AnimatePresence>

      {/* Текстовая анимация */}
      <div className="absolute top-[50%] text-center text-white text-4xl font-bold space-y-2">
        {step >= 2 && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }}>V💧D</motion.div>}
        {step >= 3 && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }}>DA💧</motion.div>}
        {step >= 4 && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }}>EC💧</motion.div>}
      </div>
    </div>
  );
}
