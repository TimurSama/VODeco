import { Suspense } from 'react'
import StartScene from './StartScene'

function App() {
  return (
    <div className="w-screen h-screen bg-[#020B13]">
      <Suspense fallback={
        <div className="w-full h-full flex items-center justify-center text-blue-500">
          Loading...
        </div>
      }>
        <StartScene />
      </Suspense>
    </div>
  )
}

export default App