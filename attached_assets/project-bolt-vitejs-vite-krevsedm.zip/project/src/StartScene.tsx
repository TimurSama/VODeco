import { useEffect, useRef } from 'react'
import { motion, useAnimate } from 'framer-motion'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import gsap from 'gsap'
import * as THREE from 'three'

function WaterDrop({ position = [0, 2, 0] }) {
  const meshRef = useRef()
  
  useEffect(() => {
    if (!meshRef.current) return
    
    gsap.to(meshRef.current.position, {
      y: 0,
      duration: 2,
      ease: 'power4.out',
      delay: 1
    })
  }, [])

  return (
    <mesh ref={meshRef} position={position}>
      <sphereGeometry args={[0.5, 32, 32]} />
      <meshPhysicalMaterial 
        color="#3B82F6"
        transparent
        opacity={0.9}
        roughness={0.1}
        metalness={0.2}
        clearcoat={1}
        clearcoatRoughness={0.1}
      />
    </mesh>
  )
}

function HexGrid() {
  const materialRef = useRef()

  useEffect(() => {
    if (!materialRef.current) return

    gsap.to(materialRef.current, {
      opacity: 0.4,
      duration: 5,
      repeat: -1,
      yoyo: true,
      ease: 'power1.inOut'
    })
  }, [])

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
      <planeGeometry args={[50, 50, 20, 20]} />
      <meshStandardMaterial 
        ref={materialRef}
        color="#1E40AF"
        wireframe
        transparent
        opacity={0.2}
      />
    </mesh>
  )
}

function Splash({ visible }) {
  return (
    <mesh visible={visible} position={[0, 0, 0]}>
      <ringGeometry args={[0.8, 1.2, 32]} />
      <meshBasicMaterial color="#3B82F6" transparent opacity={0.5} />
    </mesh>
  )
}

export default function StartScene() {
  const [scope, animate] = useAnimate()
  const audioRef = useRef()
  const splashRef = useRef(false)

  useEffect(() => {
    // Load and play ambient sound
    if (audioRef.current) {
      audioRef.current.volume = 0.3
      audioRef.current.play().catch(() => {
        console.log('Audio autoplay blocked')
      })
    }

    // Heartbeat pulses
    const timeline = gsap.timeline()
    
    for (let i = 0; i < 6; i++) {
      timeline.to('.pulse', {
        scale: 1.2,
        duration: 0.2,
        yoyo: true,
        repeat: 1,
        delay: i === 0 ? 0.5 : 0.8
      })
    }

    // Text sequence
    timeline.to('.text-v', { 
      opacity: 1, 
      duration: 0.5,
      delay: 2
    })
    timeline.to('.text-d', { 
      opacity: 1, 
      duration: 0.5 
    }, '+=1')
    timeline.to('.text-a', { 
      opacity: 1, 
      duration: 0.5 
    }, '+=1')

    return () => timeline.kill()
  }, [])

  return (
    <div ref={scope} className="w-full h-full relative overflow-hidden">
      <audio 
        ref={audioRef} 
        src="/ambient.mp3" 
        loop 
      />
      
      <Canvas>
        <PerspectiveCamera 
          makeDefault 
          position={[0, 0, 8]} 
          fov={75}
        />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1.5} />
        <OrbitControls 
          enableZoom={false}
          enablePan={false}
          maxPolarAngle={Math.PI / 2}
          minPolarAngle={Math.PI / 3}
        />
        
        <HexGrid />
        <WaterDrop />
        <Splash visible={splashRef.current} />
      </Canvas>

      <motion.div 
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 3 }}
      >
        <img 
          src="/vodeco-logo.png" 
          alt="VODeco" 
          className="w-32 h-32 pulse"
        />
      </motion.div>

      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-4xl text-blue-500 font-bold flex gap-8">
        <motion.span 
          className="text-v opacity-0"
          initial={{ opacity: 0 }}
        >
          V💧D
        </motion.span>
        <motion.span 
          className="text-d opacity-0"
          initial={{ opacity: 0 }}
        >
          DA💧
        </motion.span>
        <motion.span 
          className="text-a opacity-0"
          initial={{ opacity: 0 }}
        >
          EC💧
        </motion.span>
      </div>
    </div>
  )
}